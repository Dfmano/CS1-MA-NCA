CREATE DATABASE IF NOT EXISTS itwebshop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE itwebshop;

CREATE TABLE IF NOT EXISTS products (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    name               VARCHAR(120)   NOT NULL,
    sku                VARCHAR(40)    NOT NULL UNIQUE,
    category           VARCHAR(60)    NOT NULL,
    price              DECIMAL(10,2)  NOT NULL,
    stock              INT            NOT NULL DEFAULT 0,
    icon               VARCHAR(30)    NOT NULL DEFAULT 'device',
    short_description  VARCHAR(255)   NOT NULL,
    description        TEXT           NOT NULL,
    specs              TEXT           NOT NULL,   -- one "Key: Value" pair per line
    created_at         TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
);

-- Sample products so the shop isn't empty on first load.
INSERT INTO products (name, sku, category, price, stock, icon, short_description, description, specs) VALUES
('Ridgeline 14 Laptop', 'LAP-1401', 'Laptops', 899.00, 12, 'laptop',
 'A light 14-inch laptop built for all-day coursework and coding.',
 'The Ridgeline 14 pairs a fast mid-range processor with a sharp 14-inch display in a chassis light enough to carry between lectures all day. It boots quickly, runs cool under sustained load, and the battery comfortably covers a full day of classes.',
 'Processor: 6-core, 3.2 GHz\nMemory: 16 GB\nStorage: 512 GB SSD\nDisplay: 14" 1920x1200\nBattery: up to 11 hours\nWeight: 1.3 kg'),

('Keystroke TKL Mechanical Keyboard', 'KEY-2201', 'Peripherals', 79.00, 30, 'keyboard',
 'Tenkeyless mechanical keyboard with tactile brown switches.',
 'A tenkeyless mechanical keyboard designed for long typing sessions. Tactile switches give a clear, quiet bump on every keystroke, and the compact layout leaves more desk room for your mouse.',
 'Switch type: Tactile mechanical\nLayout: Tenkeyless (TKL)\nConnection: USB-C, detachable\nBacklight: White LED, 5 levels\nKeycaps: PBT, doubleshot'),

('ClearView 27 Monitor', 'MON-2701', 'Monitors', 249.00, 18, 'monitor',
 '27-inch QHD monitor with a 100 Hz refresh rate.',
 'A 27-inch QHD monitor sharp enough for detailed spreadsheets and code, with a 100 Hz refresh rate that keeps scrolling and window dragging smooth. The stand adjusts for height and tilt out of the box.',
 'Resolution: 2560x1440\nRefresh rate: 100 Hz\nPanel: IPS\nPorts: HDMI x2, DisplayPort x1\nStand: Height + tilt adjustable'),

('Glide Wireless Mouse', 'MOU-0900', 'Peripherals', 34.00, 45, 'mouse',
 'A lightweight wireless mouse with a 6-month battery life.',
 'A lightweight wireless mouse built for everyday use. The optical sensor tracks reliably on most surfaces, and a single AA battery lasts roughly six months of daily use.',
 'Sensor: Optical, 1600 DPI\nConnection: 2.4 GHz wireless\nBattery life: ~6 months\nButtons: 3\nWeight: 90 g'),

('JunctionHub 7-in-1 USB-C Hub', 'HUB-0710', 'Accessories', 45.00, 40, 'hub',
 'A 7-port USB-C hub that adds HDMI, card readers, and extra USB ports.',
 'A compact USB-C hub for laptops with limited ports. One cable adds an HDMI output, two USB-A ports, an SD card reader, and pass-through charging, so you can plug in a monitor and accessories at your desk in one step.',
 'Ports: HDMI, 2x USB-A 3.0, USB-C PD, SD, microSD\nVideo output: Up to 4K @ 30Hz\nPower delivery: Up to 100W pass-through\nCable length: 15 cm'),

('Vaultline 1TB SSD', 'SSD-1000', 'Storage', 89.00, 25, 'storage',
 'A portable 1TB SSD for backups and large project files.',
 'A pocket-sized external SSD for backing up coursework, project files, or media libraries. It needs no external power and reaches its full read speed over USB-C.',
 'Capacity: 1 TB\nInterface: USB-C 3.2 Gen 2\nRead speed: up to 1050 MB/s\nWrite speed: up to 1000 MB/s\nDimensions: 95 x 55 x 9 mm'),

('FocusFrame 1080p Webcam', 'CAM-1080', 'Peripherals', 59.00, 22, 'camera',
 'A 1080p webcam with a built-in privacy shutter.',
 'A 1080p webcam for video calls and recorded presentations. Autofocus keeps you sharp even if you lean in, and a sliding privacy shutter covers the lens when it is not in use.',
 'Resolution: 1080p @ 30fps\nField of view: 78°\nFocus: Autofocus\nMicrophone: Built-in, dual\nMount: Clip-on or tripod'),

('Northbeam AX Router', 'RTR-3000', 'Networking', 129.00, 15, 'router',
 'A dual-band Wi-Fi 6 router for dorms and small apartments.',
 'A dual-band Wi-Fi 6 router that covers a small apartment or dorm floor and handles several devices streaming or gaming at once without slowing down.',
 'Wi-Fi standard: Wi-Fi 6 (802.11ax)\nBands: Dual-band 2.4GHz + 5GHz\nMax speed: up to 3000 Mbps\nLAN ports: 4x Gigabit\nCoverage: up to 150 m²');
