<?php
function render_icon(string $name): string
{
    $stroke = 'currentColor';
    $common = 'fill="none" stroke="' . $stroke . '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"';

    $icons = [
        'laptop' => '<path ' . $common . ' d="M4 6h24v14H4z"/><path ' . $common . ' d="M1 24h30l-2.5-4h-25z"/>',
        'keyboard' => '<rect x="3" y="9" width="26" height="14" ' . $common . '/><path ' . $common . ' d="M7 13h2M12 13h2M17 13h2M22 13h2M7 17h14M23 17h2"/>',
        'monitor' => '<rect x="4" y="5" width="24" height="15" ' . $common . '/><path ' . $common . ' d="M12 24h8M16 20v4"/>',
        'mouse' => '<rect x="10" y="4" width="12" height="22" rx="6" ' . $common . '/><path ' . $common . ' d="M16 4v8"/>',
        'hub' => '<rect x="6" y="11" width="20" height="10" ' . $common . '/><path ' . $common . ' d="M10 21v3M16 21v3M22 21v3M9 11V8h4M23 11V8h-4"/>',
        'storage' => '<rect x="6" y="7" width="20" height="18" rx="1" ' . $common . '/><circle cx="16" cy="16" r="4" ' . $common . '/><path ' . $common . ' d="M10 11h1"/>',
        'camera' => '<rect x="3" y="9" width="19" height="14" rx="1" ' . $common . '/><circle cx="12.5" cy="16" r="4" ' . $common . '/><path ' . $common . ' d="M22 13l7-3v12l-7-3z"/>',
        'router' => '<rect x="4" y="14" width="24" height="9" ' . $common . '/><path ' . $common . ' d="M10 14V8M16 14V6M22 14v6M9 18h.01M13 18h.01"/>',
        'device' => '<rect x="6" y="6" width="20" height="20" ' . $common . '/>',
    ];

    $path = $icons[$name] ?? $icons['device'];

    return '<svg viewBox="0 0 32 28" class="icon" aria-hidden="true">' . $path . '</svg>';
}
