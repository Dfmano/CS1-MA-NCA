<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/icons.php';

// Optional category filter via ?category=Laptops
$category = $_GET['category'] ?? '';

if ($category !== '') {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE category = ? ORDER BY name');
    $stmt->execute([$category]);
} else {
    $stmt = $pdo->query('SELECT * FROM products ORDER BY name');
}
$products = $stmt->fetchAll();

// Build the category list for the filter bar
$categories = $pdo->query('SELECT DISTINCT category FROM products ORDER BY category')->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IT Supply Co. — IT products catalog</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600&family=IBM+Plex+Mono:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<header class="topbar">
    <div class="topbar-inner">
        <a href="index.php" class="brand"><span class="brand-mark">//</span>IT Supply Co.</a>
        <span class="tagline">catalog v1.0</span>
    </div>
</header>

<main>
    <div class="page-heading">
        <h1><?= $category !== '' ? htmlspecialchars($category) : 'All products' ?></h1>
        <span class="result-count"><?= count($products) ?> item<?= count($products) === 1 ? '' : 's' ?></span>
    </div>

    <nav class="filters">
        <a href="index.php" class="<?= $category === '' ? 'active' : '' ?>">All</a>
        <?php foreach ($categories as $cat): ?>
            <a href="index.php?category=<?= urlencode($cat) ?>"
               class="<?= $category === $cat ? 'active' : '' ?>">
                <?= htmlspecialchars($cat) ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <?php if (empty($products)): ?>
        <div class="empty-state">No products found in this category yet.</div>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($products as $p): ?>
                <a class="card" href="product.php?id=<?= (int)$p['id'] ?>">
                    <span class="card-icon"><?= render_icon($p['icon']) ?></span>
                    <span class="card-sku"><?= htmlspecialchars($p['sku']) ?></span>
                    <h2 class="card-name"><?= htmlspecialchars($p['name']) ?></h2>
                    <p class="card-desc"><?= htmlspecialchars($p['short_description']) ?></p>
                    <div class="card-footer">
                        <span class="card-price">€<?= number_format($p['price'], 2) ?></span>
                        <span class="card-stock <?= $p['stock'] <= 5 ? 'low' : '' ?>">
                            <?= $p['stock'] > 0 ? $p['stock'] . ' in stock' : 'out of stock' ?>
                        </span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<footer>School project webshop — data served live from MySQL</footer>

</body>
</html>
