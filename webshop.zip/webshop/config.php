<?php
$DB_HOST = 'localhost';
$DB_NAME = 'itwebshop';
$DB_USER = 'daniel';   
$DB_PASS = 'P@ssw0rd!';    

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    die('Sorry, the shop is temporarily unavailable. Please try again later.');
}
