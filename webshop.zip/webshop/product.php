<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/icons.php';

$id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    http_response_code(404);
}

// Turn the "Key: Value" spec lines into rows
$specRows = [];
if ($product) {
    foreach (explode("\n", trim($product['specs'])) as $line) {
        if (strpos($line, ':') !== false) {
            [$key, $value] = explode(':', $line, 2);
            $specRows[] = [trim($key), trim($value)];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $product ? htmlspecialchars($product['name']) . ' — DualzIT.' : 'Product not found' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600&family=IBM+Plex+Mono:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<header class="topbar">
    <div class="topbar-inner">
        <a href="index.php" class="brand"><span class="brand-mark">//</span>DualzIT.</a>
        <span class="tagline">catalog v1.0</span>
    </div>
</header>

<main>
    <a href="index.php" class="back-link">&larr; Back to all products</a>

    <?php if (!$product): ?>
        <div class="empty-state">That product doesn't exist, or may have been removed.</div>
    <?php else: ?>
        <article class="product-detail">
            <div class="product-visual">
                <?= render_icon($product['icon']) ?>
            </div>
            <div>
                <div class="product-category"><?= htmlspecialchars($product['category']) ?></div>
                <h1 class="product-name"><?= htmlspecialchars($product['name']) ?></h1>
                <div class="product-sku">SKU <?= htmlspecialchars($product['sku']) ?></div>

                <div class="product-price-row">
                    <span class="product-price">€<?= number_format($product['price'], 2) ?></span>
                    <?php if ($product['stock'] > 5): ?>
                        <span class="stock-badge in"><?= $product['stock'] ?> in stock</span>
                    <?php elseif ($product['stock'] > 0): ?>
                        <span class="stock-badge low">Only <?= $product['stock'] ?> left</span>
                    <?php else: ?>
                        <span class="stock-badge">Out of stock</span>
                    <?php endif; ?>
                </div>

                <p class="product-description"><?= htmlspecialchars($product['description']) ?></p>

                <div class="section-label">Specifications</div>
                <table class="spec-table">
                    <?php foreach ($specRows as [$key, $value]): ?>
                        <tr>
                            <td><?= htmlspecialchars($key) ?></td>
                            <td><?= htmlspecialchars($value) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </article>
    <?php endif; ?>
</main>

<footer>School project webshop — data served live from MySQL</footer>

</body>
</html>
